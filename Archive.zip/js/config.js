// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBmiq0jEr5utffbHcKvChACUMOJa7atqdM",
    authDomain: "hacktion-replay-ombgig.firebaseapp.com",
    databaseURL: "https://hacktion-replay-ombgig-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "hacktion-replay-ombgig",
    storageBucket: "hacktion-replay-ombgig.appspot.com",
    messagingSenderId: "110164206521",
    appId: "1:110164206521:web:084a23958c5d91533b8c68"
};

export { firebaseConfig };